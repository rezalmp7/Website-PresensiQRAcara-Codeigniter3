            <!-- Footer -->
            <footer class="page-footer font-small blue pt-4 col-md-12 m-0 p-0">

            <!-- Copyright -->
                <div class="footer-copyright text-center pt-3 m-0 p-0">© <?php echo date('Y'); ?> Copyright:
                    <a href="https://kecanksup.websapp.com/education/bootstrap/"> Fun Media Digital</a>
                </div>
            <!-- Copyright -->

            </footer>
            <!-- /Footer -->
            </div>
        </div>
    <!-- /Sidebar/Content/footer -->
    </div>
    <script type="text/javascript" src="<?php echo base_url(); ?>assets/vendor/jquery/jquery.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>assets/vendor/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>assets/vendor/bootstrap/dist/js/bootstrap.bundle.js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>assets/vendor/DataTables/datatables.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>assets/vendor/DataTables/DataTables-1.10.20/js/dataTables.bootstrap4.js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>assets/vendor/bootstrap/dist/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/main.js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>assets/vendor/ChartJS/Chart.js"></script>
</body>
</html>