<!-- Footer -->
<footer class="page-footer font-small blue pt-4">

<!-- Copyright -->
<div class="footer-copyright text-center py-3">© <?php echo date('Y'); ?> Copyright:
    <a href="https://kecanksup.websapp.com/education/bootstrap/"> kecank_sup</a>
</div>
<!-- Copyright -->

</footer>
<!-- /Footer -->
</div>
<script type="text/javascript" src="vendor/jquery/jquery.min.js"></script>
<script type="text/javascript" src="vendor/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
<script type="text/javascript" src="vendor/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="vendor/ChartJS/Chart.js"></script>
<script src="js/main.js"></script>
</body>